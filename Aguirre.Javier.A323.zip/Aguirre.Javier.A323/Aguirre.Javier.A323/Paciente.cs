﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Aguirre.Javier.A323
{
    public class Paciente : Persona
    {
        public string? diagnostico;

        public string? Diagnostico { get; set; }

        internal override string FichaExtra()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Apellido y Nombre{NombreCompleto}");
            sb.AppendLine($"Edad: {Edad}");
            sb.AppendLine($"Fecha de nacimiento: {Edad}");
            sb.AppendLine($"Recide en: {barrioRecidencia}");
            sb.AppendLine(diagnostico);
            
            return sb.ToString();
        }
        public Paciente(string nombre, string apellido, DateTime nacimiento, string barrioRecidencia):base(nombre,apellido,nacimiento,barrioRecidencia)
        {
            
        }
    }
}
