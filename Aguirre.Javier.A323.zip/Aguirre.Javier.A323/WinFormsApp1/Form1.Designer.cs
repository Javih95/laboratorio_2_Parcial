﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lstMedicos = new ListBox();
            lstPacientes = new ListBox();
            rtbinfoMedicos = new RichTextBox();
            btnAtender = new Button();
            btnSalir = new Button();
            lblMedicos = new Label();
            lblPacientes = new Label();
            SuspendLayout();
            // 
            // lstMedicos
            // 
            lstMedicos.FormattingEnabled = true;
            lstMedicos.ItemHeight = 25;
            lstMedicos.Location = new Point(12, 43);
            lstMedicos.Name = "lstMedicos";
            lstMedicos.Size = new Size(256, 229);
            lstMedicos.TabIndex = 0;
            lstMedicos.SelectedIndexChanged += lstMedicos_SelectedIndexChanged;
            // 
            // lstPacientes
            // 
            lstPacientes.FormattingEnabled = true;
            lstPacientes.ItemHeight = 25;
            lstPacientes.Location = new Point(319, 43);
            lstPacientes.Name = "lstPacientes";
            lstPacientes.Size = new Size(252, 229);
            lstPacientes.TabIndex = 1;
            // 
            // rtbinfoMedicos
            // 
            rtbinfoMedicos.Location = new Point(12, 294);
            rtbinfoMedicos.Name = "rtbinfoMedicos";
            rtbinfoMedicos.Size = new Size(559, 144);
            rtbinfoMedicos.TabIndex = 2;
            rtbinfoMedicos.Text = "";
            // 
            // btnAtender
            // 
            btnAtender.Location = new Point(621, 30);
            btnAtender.Name = "btnAtender";
            btnAtender.Size = new Size(167, 60);
            btnAtender.TabIndex = 3;
            btnAtender.Text = "Atender";
            btnAtender.UseVisualStyleBackColor = true;
            btnAtender.Click += btnAtender_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(621, 378);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(167, 60);
            btnSalir.TabIndex = 4;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // lblMedicos
            // 
            lblMedicos.AutoSize = true;
            lblMedicos.Location = new Point(12, 9);
            lblMedicos.Name = "lblMedicos";
            lblMedicos.Size = new Size(79, 25);
            lblMedicos.TabIndex = 5;
            lblMedicos.Text = "Medicos";
            // 
            // lblPacientes
            // 
            lblPacientes.AutoSize = true;
            lblPacientes.Location = new Point(319, 9);
            lblPacientes.Name = "lblPacientes";
            lblPacientes.Size = new Size(84, 25);
            lblPacientes.TabIndex = 6;
            lblPacientes.Text = "Pacientes";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblPacientes);
            Controls.Add(lblMedicos);
            Controls.Add(btnSalir);
            Controls.Add(btnAtender);
            Controls.Add(rtbinfoMedicos);
            Controls.Add(lstPacientes);
            Controls.Add(lstMedicos);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Aguirre Javier";
            FormClosing += Form1_FormClosing;
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListBox lstMedicos;
        private ListBox lstPacientes;
        private RichTextBox rtbinfoMedicos;
        private Button btnAtender;
        private Button btnSalir;
        private Label lblMedicos;
        private Label lblPacientes;
    }
}
