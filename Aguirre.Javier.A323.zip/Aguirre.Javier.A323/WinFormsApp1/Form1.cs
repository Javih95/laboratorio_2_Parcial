using Aguirre.Javier.A323;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAtender_Click(object sender, EventArgs e)
        {
            PersonalMedico doctor = lstMedicos.SelectedItem as PersonalMedico;
            Paciente paciente = lstPacientes.SelectedItem as Paciente;
            if (doctor is not null && paciente is not null)
            {
                string diagnostico = "Paciente curado";
                paciente.Diagnostico = diagnostico;
                Consulta consulta = new Consulta(DateTime.Now, paciente);
                lstMedicos.ClearSelected();
                lstPacientes.ClearSelected();
                MessageBox.Show($"{consulta.ToString()}", "Atenci�n finalizada", MessageBoxButtons.OK);
            }
            else
            {
                MessageBox.Show("Debe seleccionar un Medico y un Paciente para poder continuar.", "Error en los datos", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lstMedicos.Items.Add(new PersonalMedico("Gustavo", "Rivas", new DateTime(1999, 12, 12), false));
            lstMedicos.Items.Add(new PersonalMedico("Lautaro", "Galarza", new DateTime(1951, 11, 12), true));
            lstPacientes.Items.Add(new Paciente("Mathias", "Bustamante", new DateTime(1998, 6, 16), "Tigre"));
            lstPacientes.Items.Add(new Paciente("Lucas", "Ferrini", new DateTime(1989, 1, 21), "DF"));
            lstPacientes.Items.Add(new Paciente("Lucas", "Rodriguez", new DateTime(1912, 12, 12), "LaBoca"));
            lstPacientes.Items.Add(new Paciente("John Jairo", "Trelles", new DateTime(1978, 8, 30), "Medellin"));
        }

        private void lstMedicos_SelectedIndexChanged(object sender, EventArgs e)
        {
            PersonalMedico doctor = lstMedicos.SelectedItem as PersonalMedico;
            if (doctor != null)
            {
                rtbinfoMedicos.Clear();
                rtbinfoMedicos.AppendText(doctor.FichaPersonal(doctor));
            }
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("seguro desea salir?", "Confirmacion", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (dialogResult != DialogResult.Yes)
            { e.Cancel = true; }
        }
    }
}
